judger
======

Introduction
------------
It's actully a part of an online judge system, but it can also be used as a local judge.
