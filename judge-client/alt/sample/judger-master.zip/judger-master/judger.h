#ifndef __JUDGER_H__
#define __JUDGER_H__

enum {
	RET_AC,
	RET_CE,
	RET_WA,
	RET_RE,
	RET_TLE,
	RET_MLE,
	RET_OLE,
	RET_RF,
	RET_SE
};

#endif /* __JUDGER__H__ */
